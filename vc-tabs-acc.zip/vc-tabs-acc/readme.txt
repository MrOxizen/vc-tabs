===Tabs – Responsive Tabs with WooCommerce Product Tab Extension===
Contributors: biplob018
Donate link: https://www.oxilab.org
Tags: tab, tabs, responsive tabs, woocommerce tabs, tabs content, product tabs, custom tabs, woocommerce custom tabs
Requires at least: 3.8
Stable tag: 3.5.0
Requires PHP: 5.4
Tested up to: 5.7.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Tabs – Responsive Tabs with WooCommerce Product Tab Extension is essayist way to awesome WordPress Responsive Tabs Plugin with many features.

== Description ==

> **Best Responsive Tabs or Content Tabs or WooCommerce Custom Tabs Plugin for WordPress or WooCommerce**

Tabs – Responsive Tabs with WooCommerce Product Tab Extension brought to you the exclusive WordPress Tabs with WooCommerce integrated product tabs. It was designed to be the best way for adding dynamic content tabs very easily within any professional website and eCommerce store. This awesome animated tabs with CSS3 plugin is the best while creating responsive tabs with dropdown and unlimited effects & animation support. It is the most lightweight yet customizable Wordpress Tabs plugin with major page builder integration.

=Simple and UltraFast WP Tabs=

This is a fast and simple plugin to be working with. You can reduce your development time with Responsive Tabs as it is less complex and needs a least time to build tab and accordion to your webpage. And as we designed at the beginning, this plugin allows instant page load, that means you’ll never need to worry about loading extra pages to display your added FAQs or accordions. You can instantly see the preview of your each and every change. 
Also, you don’t have to take the hassles of reloading the page every time you want to save the changes in the settings. Each time you make any changes, it’ll automatically take input and save your data. 
Day by day, we’re evolving and trying hard to bring you the cutting edge technologies that you probably dreamed once. We provided all in one here with Responsive Tabs with WooCommerce Product Tabs Extension. 

=Exclusive WooCommerce Product Tabs Extensions=

With the Exclusive WooCommerce Extension, now the updated version of the Responsive Tabs is even better. For the first time, we introduce the WooCommerce Product Tabs extensions which will give you the maximum flexibility while designing tabs with our tabs plugin. Now, users can create and customize their WooCommerce product tabs content with their own design preference with our tabs plugin. With that, eCommerce webmasters can furnish their product page with the help of two powerful WP tools- WooCommerce & Responsive Tabs! 

With our Responsive Tabs, users can easily select and style their global tabs within the WooCommerce website. It’s very simple to do that from the tab's settings page. While designing tabs for your WooCommerce sites, you can easily input your custom Callback Function within the tabs. And obviously, if you want to design your own style in the front-end and embed it within the WooCommerce page, you have that convenience as well. 

You’ll have both front-end and back-end tools to design the perfect tabs for your site. Tabs – Responsive Tabs with WooCommerce Product Tabs Extension is the only tabs plugin in the market which offers that much flexibility to all users.

So, now it's time to say GoodBye to any highly paid tools which offers WooCommerce Custom tabs. Unlock the WooCommerce tabs today with our Responsive Tabs with WooCommerce Product Tabs Extension!

>  Your suggestions will make this plugin even better, so  [let us know ](https://wordpress.org/support/plugin/vc-tabs#new-post "let us know") if you need any assistance or help.

=Quick Links=

+ [Features ](https://oxilab.org/responsive-tabs/features "Demo (Features)")
+ [Demo ) ](https://oxilab.org/responsive-tabs/template/ "Demo")
+ [How to Use (Video) ](https://youtu.be/elU_RjGqX4g "How to Use (Video)")
+ [How to Use (Documentation) ](https://www.oxilab.org/docs "How to Use (Documentation)")
+ [Help and Support ](https://wordpress.org/support/plugin/vc-tabs#new-post "Help and Support")

Responsive Tabs with WooCommerce Product Tabs Extension comes with major page builder integration. That means, page builder users can now find more flexibility to use our Content Tabs within their builder interface. Major Builder Supported Responsive Tabs is totally compatible with all the page builders including Beaver Builder, Divi, Visual Composer or the most popular Elementor. 

=Lightweight yet Dynamic eCommerce Friendly Content Tabs=

Responsive Tabs was designed to be an easy and lightweight way to add tabs to your content/post/products. A developer can simply add unlimited tabs with accordion and decorate them with unlimited custom colors in an attractive and presentable fashion. Responsive Tabs with WooCommerce Product Tabs Extension also came up with some exclusive eCommerce features. And you can add and furnish your tabs within your website whether it’s for e-Commerce or any other professional websites. 

Our Tabs plugins has the most customizable user interface which allows users to add and customize their tabs and contents very easily. With its widespread settings and tools, you can easily build dynamic and effective tabs for your eCommerce based pages.

Responsive Tabs with WooCommerce Product Tabs Extension gives you a unique look and beautiful design. This is a very Powerful and Simple Tabs Creation WordPress Plugin that has interactive WooCommerce compatibility. You can add multiple tabs with unique customization in each, also you can insert some color and shadow effect on the tabs content to get a better look. By using WordPress backend you can create as much as you want and by using a shortcode, insert it into your posts and pages.

=Easy to Use Customization=

Creating Awesome animated content tabs with this plugin has never been harder. And now with the brand new interface, the designing becomes more fun. Simply Add Title and content into the tabs panel and set or customize Tabs all from one page. You can also set the global condition to your tabs from our sleek settings.There is no complex admin panel within this awesome Plugin. Responsive Tabs with WooCommerce Product Tabs Extension has a very lightweight and clean user interface that anyone can work with absolutely zero knowledge. It is a fully responsive tabs builder plugin with major extensions including WooCommerce.

You can add your content by your own chosen source, whether it’s from category pages or your custom link. You’re now free to choose from different Content Tabs types and use the provided shortcode or template to easily embed Tabs in your Website. And within the tab’s content, you can put your custom shortcode from another plugin. That allows you to add more dynamic content within your tabs contents. It’s easy and effective.

=Responsive Tabs Features=

We refurbish Responsive Tabs with WooCommerce Product Tabs Extension WP plugin with a bunch of creative features including an exclusive live-customizable admin panel. You can just drag & drop instantly to add accordion or FAQ, customize the options and control the interface. We let the admin panel free in your hand so that you can design the content at your comfort settings. Tabs with different accordion effects are an important part while creating attractive, informative and professional looking websites. Tabs – Responsive Tabs with WooCommerce Extension lets you reach your website at an apex level of responsiveness. It allows you to add tab and accordion effects to display your content/information more firmly and beautifully within WooCommerce as well. 

The design of Responsive Tabs is responsive and user friendly to any devices including mobiles and tabs. You can display both vertical and horizontal tabs style using this plugin. Add multiple Tabs on multiple pages and post. Unlimited color scheme and font style are available for creating content here.


=Advantages of the Responsive CSS3 Content Tabs= 

Tabs – Responsive Tabs with WooCommerce Product Tabs Extension is an impressive, lightweight, responsive Tab builder plugin. We used modern and elegant CSS3 style to design the accordion effects style and animations. In WordPress site using shortcodes and custom post make this Tabs with Accordions plugin more user-friendly. We developed this plugin with some touch enabled features that allow different dimensions settings. It is a standard and an intuitive WordPress plugin to create Content Tabs with stunning effects to decorate the informative content within websites. Using this plugin will help you to get a better response from viewers and pretty looking for content. 

Built in **WooCommerce Custom Product Tabs Extensions** has every feature that you can expect from a free Content Tabs plugin. It has a complete, easy-to-use tab builder with different layers with WooCommerce extensions built in. That means you can now easily embed tabs within your WooCommerce builder using our extensions. Tabs make the product page more responsive and informative for every eCommerce business website. Oxilab Developers make this plugin easier to WooCommerce Users by adding an awesome panel for WooCommerce extension. Just add the Responsive Tabs extensions in the builder and forget about all other complex tabs builder.

**Fully live design and custom interface** Never again work on the backend and guess what the frontend will look like. With Responsive Tabs with WooCommerce Product Tabs Extension, every time you edit the page and simultaneously see exactly how it looks like. Responsive Tabs features live editing, with no need to press update or go to preview mode. Also you can reshape your preview section and customize the tools positioning to arrange them at your comfort. This plugin developed with a strong and customizable interface and you can use the provided template to easily embed Tabs in your Website. With this plugin you can create unlimited Tabs with Accordion using unlimited shortcode. So you can display your created Tabs and Accordions on multiple pages and post by using one single shortcode! Putting the condition has never been that easier which you’ll get in every Oxilab product.
 
**Multiple styles and layouts** Our elegant designers prepared over 25 styles. With the Tabs – Responsive Tabs with WooCommerce Product Tabs Extension plugin, you can select your preferred style from multiple Tabs styles and Tabs layouts. You can use either the toggle Tabs or Accordion Tabs style to display one expanded Tabs on click. Or you can also choose to display all Tabs on the same page with the style optional list that offers more traditional Tabs and Accordions layout.

**Mobile Editing and Canvas** plugin comes with an exclusive tool set that lets you create truly a responsive website in a whole new and visual way. From different font size per device, to reverse column ordering, this is the most powerful solution for creating perfect mobile pages. You can develop your webpage with our plugin simply using your mobile device. There are separate options for different device settings. You can customly edit for all screen dimensions. Our developed canvas works on any theme, and lets you get rid of the header area so you get a blank template to work on. Overall, Responsive Tabs with WooCommerce Product Tabs Extension is the best solution for engaging more viewers and grabbing their actions.

**Best eCommerce Tabs solution** Using Responsive Tabs, a Wordpress developer can easily create SEO-friendly Tabs links to individual Tabs posts so that their customers simply reach to exactly the right information, right away. This works amazingly within an eCommerce store to add more value. With the plugin, you can easily add a tab with accordion to each product page, so that your customers can easily see the information about the products they’re browsing. You can easily add the product descriptions as well as other info including specification, review, , FAQ and so on. It is a perfect solution for eCommerce stores. Also, you can add links in your Tabs to redirect popular social media, such as Facebook, Twitter and Pinterest so that your customers can help you to spread the word about your product. It is very helpful to grow a business.

**Designer’s Touch** We designed and developed the Responsive Tabs with WooCommerce Product Tabs Extension with the smooth touch of design. Here you create accordions that have “the designer touch”, as we develop this plugin including unique and exceptional features like animation, box shadows, background color, border radius, custom padding, custom positioning, advanced buttons and much more. We’ve added a Library to Responsive Tabs which includes a collection of beautiful templates.

**Built for Developers** Responsive Tabs with WooCommerce Extension was designed to be the most developer-friendly Tab building plugin available for WordPress. It was also built on top of a solid extension framework, which means different functionality is separated out into different areas in the codebase. It also means the core plugin is lightweight, but still allowing for the most flexibility. There are so many custom tools in our plugin for the developer’s convenience. Create pages and sections using tabs, and reuse these on different pages, or export to a whole different website as you want. 

**Custom CSS** Wordpress professional developers can get advanced tools and freedom of creativity with our plugin. They can use their custom styling within Responsive Tabs with WooCommerce Extension. Advanced developers can add their custom css into the plugin very easily. There’s a section we’ve left for this task.

Tabs – Responsive Tabs with WooCommerce Custom Tabs Extension can help to improve your eCommerce or business website in a number of ways:

> +Add Interactivity: With accordions and tabs, you can make better use of the available space on the page. You can save some space and use them for other effective purposes.
> +Add Style: Responsive Tabs with WooCommerce Extension can help make your site look more professional and better polished than other sites.
> +Save Space: Responsive Tabs with WooCommerce Extension can save a lot of space on the page making your website look less cluttered.
> +Separating Content: Showing content only when required while the rest remains invisible dividing the content into parts.
> +Add Dynamic Tools: You can add some stunning dynamic functionality to your tabs like triggers, activator events, custom content type and so on.
> +Adds a set of horizontal tabs which changes to an accordion on narrow viewports
> +Responsive Tabs with Accordions are created with jQuery
> +Supports multiple sets of tabs on same page
> +Uses Semantic header and Content markup
> +Aria attributes and roles aid screen reader accessibility
> +Tabs and content are accessible via keyboard/click/hover

>  Your suggestions will make this plugin even better, so  [let us know ](https://wordpress.org/support/plugin/vc-tabs#new-post "let us know") if you need any assistance or help.

=Key Features of Responsive Tabs with WooCommerce Custom Tabs Extension=

Responsive Tabs with WooCommerce Product tabs Extension aims to make your website more attractive and good-looking. The Tabs Plugin has many functions. So you can create Tabs not only with title and Content, but also Customize with CSS forms like font-size, color, background color, border-radius, box-shadow, padding, margin and more. Just change the value and Make your Website with Custom Content Tabs. Let’s see, which features the plugin offers-

> +**Awesome Interface** with a simple, easy to use interface – perfect for individual users, developers & clients!
> +**Custom Content** Under tabs, you can add custom content sources. You can choose from a custom link, different category, posts or simply write your description.
> +**One-Click Presets** to provide the easiest way to customize the display of your tabs without editing any code. You can use the default Responsive styles or one of the included one-click presets as a starting point for customization. It also enables you to easily add icons to your tab titles.
> +**Awesome Admin Panel** the Admin panel of the plugin is way more better from the others similar plugins. Users will find more comfort and interest while working with the plugin.
> +**Instant Customizing Option** With the instant customizing facility users can edit/delete/update the Tabs Content at any time they want.
> +**Demo** For your convenience, we’ve decorated an interactive demo page with stunning . You can select a style from the template library. Select the page instantly and very fast before starting to add the information. We developed 25 Awesome, modern and unique Tabs templates on our demo page and more are coming soon.
> +**Responsive Link to Tab** the plugin provides a simple shortcode to create links to specific tabs, which can appear anywhere on the same page as the tabgroup without the page needing to reload.  
> +**Tab to URL Link** This feature enables you to set one or more of your tabs to act as a link to any URL.  
> +**Load Accordion Closed** changes the default behavior when the tabs are displayed as an accordion so no accordion sections are open when the page initially loads.
> +**Target URL** You can use a ‘target’ URL parameter to set which tab will be open when the page initially loads. The value of this parameter is based on the tab title specified in the shortcode, but formatted with punctuation & special characters removed, accents removed, and with dashes replacing the spaces.
> +**Icon** You can choose the icon for each tab or accordion from the available font’s library in Tabs – Responsive Tabs with WooCommerce Extension.
> +**Tab or Accordion Alignment** Most of our users have asked for this feature. We have added a comprehensive option for alignment. You can now align your tabs or accordions: left, right or center with a more flexible way.
> +**Flexible ways to Position** Tabs are very flexible and customizable, horizontal and vertical Tabs and it can be positioned in many Flexible ways.
> +**Content transition animations** With this update, we’ve added more animation effects to the list so that you can have more freedom. A list of animation effects: (Random, Scale, Bounce, FadeUp, FadeDown, FadeLeft, FadeRight, SlideUp, SlideDown, SlideLeft, SlideRight, ScrollUp, ScrollDown ScrollLeft, ScrollRight, BounceUp, BounceDownBounceLeft, BounceRight, HorizontalFlip, VerticalFlip, RotateDownLeft, RotateDownRight, RotateUpLeft, RotateUpRight, TopZoom, BottomZoom, LeftZoom, RightZoom ). 
> +**Touch gestures** switch between slides easily and flexibility with the support of swipe gestures, especially when we upgraded Tabs – Responsive Tabs with WooCommerce Extension with many slides on the mobile devices. No need to worry, no need to trouble switch the dropdown menu on mobile devices. Tested on iOS, Android, Windows Phone device.
> +**Flat design** Flat, clean and minimalist design throughout Responsive Tabs with WooCommerce Custom Tabs Extension, respond most of the modern template. Same time easily creates a new style in the css file.  
> +**Free support & update** The Tabs – Responsive Tabs with WooCommerce Extension always upgrade itself with new features, regular updates as well as improve existing features. You'll always get free support from our expert developers once you switch on this plugin. The plugin author himself often gives the answer to support forum questions. So there’s nothing to worry about if you get stuck anywhere during developing your site using our plugins.
> +**Shortcodes** If you need to display any short-codes in the product tab or accordion, you can use this type.
> +WordPress Multi Site compatible
> +**Fast** only the minimum JavaScript/CSS is included on your page
> +**Maximum Compatibility** Responsive Tabs with WooCommerce Product Tabs Extension plugin works with any WordPress themes, and very easy to install and tune the tab plugin.
> +25 Unique and Awesome Templates
> +Random effects – including ‘one’ effects and ‘out-in’ effects. 
> +Lifetime Update and support
> +The Plugin is provided with the support, upon request within 24 hours
> +Fully Optimized Template
> +Provides attractive and stunning interface
> +Work with best Setting Panel
> +Built in Widget and Shortcode
> +Easy to customize to fit any design and color scheme. 
> +Can display any content, video, Image or other elements. 
> +Vertical & Horizontal Tabs Layouts. 
> +Add and remove Tabs item from backend Quickly.
> +Super smooth hardware accelerated CSS3 transitions with jQuery fallback.


=Highly Customizable Awesome Content Tabs with WooCommerce=

Responsive Tabs plugin come with their own settings and preset skins that can be customized without Zero HTML or CSS knowledge! You can define multiple instances of tabs, then you can arrange the content with the help of widgets and shortcodes. By using the coolest features of animated Content Tabs, you can choose to add navigation arrows in the tab header or you can add a menu button and display the extra tabs in a popup menu. You can also select to hide tab text and only display tab icons on small screen devices. Also, we’ve put the comprehensive custom font awesome library for you to pick your favourite icon for the tabs.

Tabs – Responsive Tabs with WooCommerce Custom Tabs Extension can help to improve your website in a number of ways such as WooCommerce tabs compatibility, strong interactivity, unlimited access to styles, saving spaces, add more value and make content more attractive, separating content and much more! 

All features in this plugin are fully Responsive and Customizable. With the Responsive Content Tabs, you can make better use of the available space on the page of your site. This can help make your site look more professional and better polished than other sites. It can save a lot of space on the page making your website look less cluttered. The Animated Content Tabs with WooCommerce Extensions allow showing content only when required while the rest tabs remain invisible dividing the content into parts.

>  Your suggestions will make this plugin even better, so  [let us know ](https://wordpress.org/support/plugin/vc-tabs#new-post "let us know") if you need any assistance or help.

=Lots of Interactive Tabs Features=

We packed lots of the most useful tabs features into our Responsive Tabs with WooCommerce Product Tabs Extensions. True, that’s way more than we had to offer, but we wanted to spare nothing from you, so you can reach the top of your design capabilities. Here is a list what we offer:

> +WooCommerce Tabs- Now you can add your WooCommerce tabs using our plugin.
> +Custom Content- Add content from wherever you want.
> +General Tabs type- Most common tabs style with some basic effects are designed for you in the demo. We decorated this type with a wide range of customizations and editing options. You can import any style you like anytime from the demo page and start customizing it to embed within your post/page by using shortcode.
> +Ordered Tabs- with Ordered Tabs style there are some templates available where you can customize tabs in order. These templates help you to show the content more pretty and outstanding looking.
> +Icon Tabs- Here with the Icon Tabs effect you can choose an icon for the tabs title. With over 600+ font awesome icon collections you can choose your own by entering the name of the icon. You can also use social icons or any custom icon you need. But for adding your own designed icon you have to work with some custom CSS style sheet. Please contact us for getting some help regarding custom CSS.
> +Hardware accelerated – Responsive Tabs with Accordions completely used new techniques used in the transition effects to create a smooth transition, fastest, and saves the system memory.  
> +Text/Visual Editor- You can get a text editor type interface to edit the content details. Here you can add custom html or css style. You can add html in the tabs content at the details section. With this convenience, you can easily customize the style and effect of the text if you want to.
> +HTML Content – Place absolutely any HTML content (Images, Audio, and Video) into tabs. You can also have external links or a link to a specific tab.
> +Unlimited Shortcode- Here you can create an unlimited accordion group with unlimited shortcode. So using shortcodes you can display your tabs on multiple pages and post.
> +No Coding required- This plugin is so simple and clean UI with user friendly functions. Add new tabs and then easily publish it within minutes. It works with any theme. We have tested the Responsive Tabs with WooCommerce Extensions with multiple themes, and it worked perfectly on every theme. So the design is very clean and will work with your custom theme as well.
> +Tabs Borders and Shadows – All borders and shadows of the tab’s title and description have multiple configuration options. You can fully customize size, color, transparency of the tabs interface. Shadow also has an additional blur option for the tab contents. All options could be configured with a tab control or defined values manually in edit fields of the tabs with accordion content options. 
> +Styling Text of the Tabs Content – We’ve given you the maximum customization options for every section. All text on the Tabs could be styled in both front and backend. For the title and description of the tab we have advanced settings for customization of the font. We’ve designed separate sections for customizing both heading and description. You can select font style, size and colors for the static and hovered text of the image hover elements. We’ve separated the heading and description section into two parts on the editor so that you can customize the typography and styles of the text more deeply.
> +Color Pickers – All Content Tabs elements implement a very comfortable color picker. With the color picker option, you can define color multiple ways. For contents you can select transparency for the color. Colors could be defined in HEX or RGB style.
> +Add Icon/Number/Image into Tabs- You can choose the icon for each tab heading from the available font awesome icon library in Content Tabs Builder. Also, you can add number or image instead of icon besides your tabs title. We’ve designed a unique and easy doing interface with a lot of customization options and features. You can select icon tabs from the icon integrated template or just create and customize your own.
> +Touch gestures – switch between slides easily and flexibility with support swipe gestures, especially with tabs and accordion that have many slides effects on the mobile devices. No need to worry, no need to trouble, just switch the dropdown menu on mobile devices. Tested on iOS, Android, Windows Phone device.
> +Custom Image- You can also add images besides your tabs heading text.
> +Custom Trigger and Activator
> +Heading- Add eye-catching headlines.
> +Image- Add and customize the image size, opacity and other settings.
> +Text Editor- A custom text editor, just like the WordPress editor.
> +Tabs- Vertical or horizontal tabs that display different pieces of content.
> +Accordion- A collapsible display of content.
> +Toggle-Like Accordion, for FAQ pages.
> +HTML- Insert custom code into the page.
> +Shortcode- Easily add shortcodes from any plugin into the page.

The Tabs – Responsive Tabs with WooCommerce Custom Tabs Extension is a very professional animator tabs builder plugin with WooCommerce extensions. It has an amazing transition effect sequence of the other tabs. On the style page, you’ll find 25 different styles with different types of tabs style and effect. Over time, we will add more new effects on our plugin by updating them. 

If you wish to spice up your eCommerce store, corporate website, blog, or a message board with tabs, it’s easy to show any content, video, price or data tables, form or other elements with Responsive Tabs. The Responsive Tabs with WooCommerce Extensions is 100% responsive and compatible with any device including mobile, tablets, desktop computers and all modern web browsers which include iPhone, iPad, Android, Chrome, Safari, Firefox, Opera, Internet Explorer 7/8/9/10/11 and also Microsoft Edge.

== Installation ==

### Uploading in WordPress Dashboard
1. First download the ZIP file from Wordpress website
2. Log in to your website administrator panel   
3. Go to the 'Add New' in the plugins dashboard, click "Upload Plugin"
4. Upload [Responsive Tabs with WooCommerce Custom Tabs Extension](https://wordpress.org/plugins/vc-tabs/) ZIP file by choosing it from your computer
5. Click **Install Now** button
6. Then click **Activate Plugin** button.
7. You can see the slider plugin installed on Wordpress left menu.

### Using The WordPress Plugin slider Dashboard

1. Go to the 'Add New' in the plugins dashboard
2. Search for 'Responsive Tabs with WooCommerce Custom Tabs Extension'
3. Click **Install Now** button
4. Then click **Activate Plugin** button
5. You can see the plugin installed on Wordpress left menu

### Using FTP

1. Download the ZIP file from Wordpress website
2. Extract the **vc-tabs** directory to your computer
3. Upload the **vc-tabs** directory to the **/wp-content/plugins/** directory
4. Activate the plugin in the Plugin dashboard
5. You can see the plugin installed on Wordpress left menu

Now you can set your Content Tabs options and use our Tabs Plugin.


== Screenshots ==

1. Responsive tabs Template Selection Page 
2. Shortcode Customization with Live Previews 
3. Easy Settings Interface with WooCommerce Extension Active Option
4. WooCommerce Custom tabs with Tabs Layouts Selection

== Frequently Asked Questions ==

= Don't Work on My Site? =

 There are severals reasons where you need to investigate when troubleshooting  any plugins on Your sites 

**Add Incorrectly shortcodes**

Most of plugins are used by shortcodes into Website. By Mistake of use wrong shortcode will can't output data of any plugin. So Be sure that you are copied right file from shortcode panel. on Our Tabs plugins can't work at same reasons

**Plugin or theme conflicts**

This is most common Problem on website. Hope You can't face this type of problem on Our Tabs Plugins. Perhaps We select CSS with unique CSS name and file name also. If you face any Problem Then review the topics in the [plugin support forum](http://wordpress.org/support/plugin/vc-tabs/ "Responsive Tabs with WooCommerce Custom Tabs Extension")

= What levels of support are available? =

You will get support of our tabs Plugin if You face any Problem. To get Support Please open a new topic on the [plugin support forum](http://wordpress.org/support/plugin/vc-tabs/ "Responsive Tabs with WooCommerce Custom Tabs Extension plugin support forum") all communication must take place on the forum.

Or Contact Via email from our Contact us Page [Oxilab Development](https://www.oxilab.org/contact-us/) 

= Does this plugin work with responsive Themes? =

Yes Our Responsive Tabs with WooCommerce Custom Tabs Extension plugin Work Perfectly with Responsive Themes.

= Does it work with non-responsive Themes? =

On Non Responsive Themes Our Responsive Tabs with WooCommerce Custom Tabs Extension plugin also work Perfectly. Perhaps Our Plugin will automatically  Set with mobile version. 


== Changelog ==

= 3.5.0 =
*Update Import Export Options
*Separate Woocommerce Extension
*Add Accordions Template

= 3.4.0 =
*Update Old UI Bugs

= 3.3.2 =
*Update Admin Bugs

= 3.3.0 =
*Update Admin Interface
*Add WooCommerce Extension

= 3.2.2 =
*Solved  Link Issues

= 3.2.1 =
*Solved Admin Bugs

= 3.2 =
*Solved Template 4 Bugs
*Update Shortcode Info Panel

= 3.1 =
*Update admin panel

= 3.0 =
*Update with Page Builders

= 2.9 =
*Bugs Fixed 

= 2.8 =
*Update Gutenberg Compatible  

= 2.7 =
*Update Link Options 
*Update Animation Type 

= 2.6 =
*Bug Fixed

= 2.5 =
*Add Font Awesome 5.0
*Bug Fixed

= 2.4 =
*Update font awesome Issue
*More Responsive
*Bug Fixed
*Rename Option

= 2.3 =
*Update Mobile Issue
*More Responsive
*Bug Fixed

= 2.2 =
* Update Font Awesome

= 2.1 =
* Add user capabilities
* More theme capabilities  

= 2.0 =
* Update some Data

= 1.2 =
* Update some Data

= 1.1.2 =
* Add 10 more Templates 
* Update some Data

= 1.1 =
* Add 5 more Templates 
* Update Information

= 1.0 =
* Initial Release


== Upgrade Notice ==

= 3.5.0 =
Update Import Export Options
Separate Woocommerce Extension
Add Accordions Template

= 3.4.0 =
Update Old UI Bugs

= 3.3.2 =
Update Admin Bugs

= 3.3.0 =
Update Admin Interface
Add WooCommerce Extension
= 3.2.2 =
Solved  Link Issues

= 3.2.1 =
Solved Admin Bugs

= 3.2 =
Solved Template 4 Bugs
Update Shortcode Info Panel

= 3.1 =
Update admin panel

= 2.9 =
Update with Page Builders

= 2.9 =
Bugs Fixed

= 2.8 =
Update Gutenberg Compatible 

= 2.7 =
Update Link Options 
Update Animation Type 

= 2.6 =
Bug Fixed

= 2.5 =
Add Font Awesome 5.0
Bug Fixed

= 2.4 =
Update font awesome Issue
More Responsive
Bug Fixed
Rename Option
= 2.3 =
Update Mobile Issue
More Responsive
Bug Fixed

= 2.2 =
Update Font Awesome

= 2.1 =
Add user capabilities
More theme capabilities 

= 2.0 =
Update some Data

= 1.2 =
Update some Data

= 1.1.2 =
Added more 10 Templates 