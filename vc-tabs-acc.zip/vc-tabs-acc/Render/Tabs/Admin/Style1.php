<?php

namespace OXI_TABS_PLUGINS\Render\Tabs\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_TABS_PLUGINS\Render\Tabs\Helper;
use OXI_TABS_PLUGINS\Render\Controls as Controls;

class Style1 extends Helper {

    
}
