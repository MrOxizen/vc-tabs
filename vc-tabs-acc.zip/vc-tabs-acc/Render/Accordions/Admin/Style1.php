<?php

namespace OXI_TABS_PLUGINS\Render\Accordions\Admin;

/**
 * Description of Effects1
 *
 * @author biplo
 */
use OXI_TABS_PLUGINS\Render\Accordions\Helper;
use OXI_TABS_PLUGINS\Render\Controls as Controls;

class Style1 extends Helper {

    
}
